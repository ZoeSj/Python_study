# @File    : setup.py
# @Date    : 2020-05-26
# @Author  : shengjia

from distutils.core import setup

setup(
    name='nester',
    version='1.1.0',
    py_modules=['nester'],
    author='zoe',
    author_email='shengjiamo@163.com',
    url='https://zoesj.github.io/',
    description='a sample printer of nested lists',
)
